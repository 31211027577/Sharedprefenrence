package com.example.sharepreference;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {

    TextView txtres;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        txtres = findViewById(R.id.txtres);
        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("sharedPrefs", Context.MODE_PRIVATE);

        String num = sharedPreferences.getString("text","");
        int color = sharedPreferences.getInt("color",0);
        txtres.setText(num);
        txtres.setBackgroundColor(color);
    }
}