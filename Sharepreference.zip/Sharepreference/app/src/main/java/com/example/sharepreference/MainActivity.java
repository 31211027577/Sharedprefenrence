package com.example.sharepreference;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    Button btncount, btnsave, btnview, red, green;
    Random r = new Random();
    int count = r.nextInt(20);
    public static final String SHARED_PREFS = "sharedPrefs";
    public static final String TEXT = "text";
    String text;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        btncount = findViewById(R.id.btncount);
        btnsave = findViewById(R.id.btnsave);
        btnview = findViewById(R.id.btnview);
        red = findViewById(R.id.red);
        green = findViewById(R.id.green);

        textView.setText(""+count);

        btncount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                count++;
                textView.setText("" + count);
            }
        });

        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);

        btnsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                text = textView.getText().toString();

                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("text",text);
                editor.commit();
                Toast.makeText(MainActivity.this, "Saved", Toast.LENGTH_SHORT).show();
            }
        });

        btnview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ResultActivity.class);
                startActivity(intent);
            }
        });

        red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textView.setBackgroundColor(Color.RED);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("color",Color.RED);
                editor.commit();
            }
        });
        green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textView.setBackgroundColor(Color.GREEN);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("color",Color.GREEN);
                editor.commit();
            }
        });

    }

}